import 'dotenv/config';
import { publicCsv, publicJson } from './handler';
import type { APIGatewayProxyEventV2 } from 'aws-lambda';

async function run() {
  const spreadsheetId = process.env.SHEET_ID || '';
  const gidOrSheet    = process.env.GID || process.env.SHEET_NAME || '0';

  if (!spreadsheetId) {
    console.error('SHEET_ID belum di-set di .env');
    process.exit(1);
  }

  const baseEvent: APIGatewayProxyEventV2 = {
    version: '2.0',
    routeKey: 'GET /csv/{spreadsheetId}/{gidOrSheet}',
    rawPath: `/csv/${spreadsheetId}/${gidOrSheet}`,
    rawQueryString: '',
    headers: {},
    requestContext: {} as any,
    isBase64Encoded: false,
    pathParameters: { spreadsheetId, gidOrSheet },
    queryStringParameters: undefined,
    stageVariables: undefined,
    body: undefined,
    cookies: []
  };

  const csvRes = await publicCsv(baseEvent);
  console.log('=== CSV STATUS ===', csvRes.statusCode);
  console.log(csvRes.body?.slice(0, 300));

  const jsonEvent: APIGatewayProxyEventV2 = {
    ...baseEvent,
    routeKey: 'GET /json/{spreadsheetId}/{gidOrSheet}',
    rawPath: `/json/${spreadsheetId}/${gidOrSheet}`,
  };
  const jsonRes = await publicJson(jsonEvent);
  console.log('=== JSON STATUS ===', jsonRes.statusCode);
  console.log(jsonRes.body?.slice(0, 300));
}

run().catch(err => { console.error(err); process.exit(1); });
